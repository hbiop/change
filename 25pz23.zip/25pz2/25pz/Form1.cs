﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form1 : Form
    {
        TimeSpan dsn;

        public Form1()
        {
            InitializeComponent();
            
            Form4 Main2 = this.Owner as Form4;
            Form5 Main3 = this.Owner as Form5;
            Form6 Main4 = this.Owner as Form6;
            lb_time.Text = "";
            DateTime dtm = new DateTime(2023, 06, 20);
            lb_time.Text = "";
            dsn = dtm - DateTime.Now;
            string a = Convert.ToString(dsn.Days) + "  Дней  " + Convert.ToString(dsn.Hours) + "  Часов  " + Convert.ToString(dsn.Minutes) + "  Минут до старта марафона";
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 AddRec = new Form2();
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void btn_BMI_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 AddRec = new Form4();
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            
            Application.Exit();
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dtm;
            
            if (dsn.Days > 0 || dsn.Hours > 0 || dsn.Minutes > 0)
            {
                dtm = new DateTime(2023, 06, 20);
                dsn = dtm - DateTime.Now;
                string a = Convert.ToString(dsn.Days) + "  Дней  " + Convert.ToString(dsn.Hours) + "  Часов  " + Convert.ToString(dsn.Minutes) + "  Минут до старта марафона";
                lb_time.Text = a;
            }
            else
            {
                timer1.Enabled= false;
            }
        }

        private void btn_timeinfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 AddRec = new Form5();
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void btn_BMR_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 AddRec = new Form6();
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }
    }
}
