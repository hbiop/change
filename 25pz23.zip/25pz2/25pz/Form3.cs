﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            pB_map.SizeMode = PictureBoxSizeMode.StretchImage;
            BTN_checkpoint1.Parent = pB_map;
            BTN_checkpoint2.Parent = pB_map;
            BTN_checkpoint3.Parent = pB_map;
            BTN_checkpoint4.Parent = pB_map;
            BTN_checkpoint5.Parent = pB_map;
            BTN_checkpoint6.Parent = pB_map;
            BTN_checkpoint7.Parent = pB_map;
            BTN_checkpoint8.Parent = pB_map;
            BTN_start.Parent = pB_map;
            BTN_half.Parent = pB_map;
            BTN_rast.Parent = pB_map;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Form2 Main = this.Owner as Form2;
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BTN_checkpoint1_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 1";
            LB_nld.Text = "Avenida Rudge";
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pnl_checkpoint1.Visible = false;
            pnl_checkpoint1.Visible = true;
            pB_toilets.Visible = false;
            lb_toilets.Visible = false;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            pnl_checkpoint1.Visible = false;
        

        }

        private void BTN_checkpoint2_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 2";
            LB_nld.Text = "Theatro Municipal";
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pnl_checkpoint1.Visible = false;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = true;
            lb_inf.Visible = true;
            pb_Med.Visible = true;
            lb_med.Visible = true;
            pnl_checkpoint1.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 AddRec = new Form2();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void lb_landmark_Click(object sender, EventArgs e)
        {

        }

        private void LB_nld_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void BTN_checkpoint3_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 3";
            LB_nld.Text = "Parque do Ibirapuera";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_checkpoint4_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 4";
            LB_nld.Text = "Jardim Luzitania";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = true;
            lb_med.Visible = true;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_checkpoint5_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 5";
            LB_nld.Text = "Iguatemi";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = true;
            lb_inf.Visible = true;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_checkpoint6_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 6";
            LB_nld.Text = "Rua Lisboa";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_checkpoint7_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 7";
            LB_nld.Text = "Cemitério da Consolação";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = true;
            lb_inf.Visible = true;
            pb_Med.Visible = true;
            lb_med.Visible = true;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_checkpoint8_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "Checkpoint 8";
            LB_nld.Text = "Cemitério da Consolação";
            pB_en.Visible = true;
            lb_en.Visible = true;
            pB_drinks.Visible = true;
            lb_drinks.Visible = true;
            pnl_checkpoint1.Visible = false;
            pB_toilets.Visible = true;
            lb_toilets.Visible = true;
            pB_inf.Visible = true;
            lb_inf.Visible = true;
            pb_Med.Visible = true;
            lb_med.Visible = true;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_start_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "srart";
            lb_landmark.Text = "";
            LB_nld.Text = "";
            label1.Text = "";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = false;
            lb_en.Visible = false;
            pB_drinks.Visible = false;
            lb_drinks.Visible=false;
            pB_toilets.Visible = false;
            lb_toilets.Visible = false;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_half_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "half";
            lb_landmark.Text = "";
            LB_nld.Text = "";
            label1.Text = "";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = false;
            lb_en.Visible = false;
            pB_drinks.Visible = false;
            lb_drinks.Visible = false;
            pB_toilets.Visible = false;
            lb_toilets.Visible = false;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }

        private void BTN_rast_Click(object sender, EventArgs e)
        {
            lb_name2.Text = "четверть";
            lb_landmark.Text = "";
            LB_nld.Text = "";
            label1.Text = "";
            pnl_checkpoint1.Visible = false;
            pB_en.Visible = false;
            lb_en.Visible = false;
            pB_drinks.Visible = false;
            lb_drinks.Visible = false;
            pB_toilets.Visible = false;
            lb_toilets.Visible = false;
            pB_inf.Visible = false;
            lb_inf.Visible = false;
            pb_Med.Visible = false;
            lb_med.Visible = false;
            pnl_checkpoint1.Visible = true;
        }
    }
}
