﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _25pz
{
    public partial class Form2 : Form
    {
        TimeSpan dsn;
        public Form2()
        {
            InitializeComponent();
           
            Form3 Main = this.Owner as Form3;
            lb_time.Text = "";
            DateTime dtm = new DateTime(2023, 06, 20);
            lb_time.Text = "";
            dsn = dtm - DateTime.Now;
            string a = Convert.ToString(dsn.Days) + "  Дней  " + Convert.ToString(dsn.Hours) + "  Часов  " + Convert.ToString(dsn.Minutes) + "  Минут до старта марафона";
            lb_time.Text = a;
            string info = Properties.Resources.marathon_skills_2016_marathon_info;
            tB_inf.Multiline = true;
            tB_inf.Width = 430;
            tB_inf.Height = 190;
            tB_inf.Text = info;
            Form1 Main2 = this.Owner as Form1;
            pB_map.SizeMode = PictureBoxSizeMode.StretchImage;
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pB_map_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 AddRec = new Form3();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();

        }

        public void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();

        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Ханой, Вьетнам (2012)";
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            DateTime dtm;

            if (dsn.Days > 0 || dsn.Hours > 0 || dsn.Minutes > 0)
            {
                dtm = new DateTime(2023, 06, 20);
                dsn = dtm - DateTime.Now;
                string a = Convert.ToString(dsn.Days) + "  Дней  " + Convert.ToString(dsn.Hours) + "  Часов  " + Convert.ToString(dsn.Minutes) + "  Минут до старта марафона";
                lb_time.Text = a;
            }
            else
            {
                timer1.Enabled = false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Осака, Япония (2014)";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Лейпциг, Германия (2013)";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Йорк, Англия (2011)";
        }
    }
}
