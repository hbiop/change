﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form5 : Form
    {
        TimeSpan dsn;
        public Form5()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
            label2.Text = string.Empty;
            DateTime dtm = new DateTime(2023, 06, 20);
            lb_time.Text = "";
            dsn = dtm - DateTime.Now;
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.f1_car;
            label2.Text = "Скорость: 345 km/H";
            label1.Text = "f1";
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.slug;
            label2.Text = "Скорость:0.01 km/H";
            label1.Text = "slug";
        }

        private void panel4_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.horse;
            label2.Text = "Скорость:15 km/H";
            label1.Text = "horse";
        }

        private void panel5_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.sloth;
            label2.Text = "Скорость:0.12 km/H";
            label1.Text = "sloth";
        }

        private void panel6_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.capybara;
            label2.Text = "Скорость:35 km/H";
            label1.Text = "capybara";
        }

        private void panel7_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.jaguar;
            label2.Text = "Скорость:80 km/H";
            label1.Text = "jaguar";
        }

        private void panel8_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.worm;
            label2.Text = "Скорость:0.03 km/H";
            label1.Text = "worm";
        }

        private void panel13_Click(object sender, EventArgs e)
        {
            
             pB_pic.Image = Properties.Resources.bus;
             label2.Text = "Расстояние:10 m";
            label1.Text = "bus";

        }

        private void panel12_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.pair_of_havaianas;
            label2.Text = "Расстояние:0.245 m";
            label1.Text = "pair of havaianas";
        }

        private void panel11_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.airbus_a380;
            label2.Text = "Расстояние:73 m";
            label1.Text = "airbus a380";
        }

        private void panel10_Click(object sender, EventArgs e)
        {     
            pB_pic.Image = Properties.Resources.football_field;
            label2.Text = "Расстояние:105 m";
            label1.Text = "football field";
        }

        private void panel9_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.ronaldinho;
            label2.Text = "Расстояние:1.81 m";
            label1.Text = "ronaldinho";
        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dtm;

            if (dsn.Days > 0 || dsn.Hours > 0 || dsn.Minutes > 0)
            {
                dtm = new DateTime(2023, 06, 20);
                dsn = dtm - DateTime.Now;
                string a = Convert.ToString(dsn.Days) + "  Дней  " + Convert.ToString(dsn.Hours) + "  Часов  " + Convert.ToString(dsn.Minutes) + "  Минут до старта марафона";
                lb_time.Text = a;
            }
            else
            {
                timer1.Enabled = false;
            }
        }
    }
}
