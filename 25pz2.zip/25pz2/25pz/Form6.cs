﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form6 : Form
    {
        int a = 0;
        public Form6()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
            pB_male.SizeMode = PictureBoxSizeMode.StretchImage;
            pB_female.SizeMode = PictureBoxSizeMode.StretchImage;
            label4.Text = string.Empty; 
        }

        private void Form6_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btn_schet_Click(object sender, EventArgs e)
        {
            double sc;
            if (a == 0)
            {
                sc = 88.36 + (13.4 * Convert.ToDouble(tB_ves.Text)) + (4.8*Convert.ToDouble(tB_rost.Text)) - (5.7 * Convert.ToDouble(textBox1.Text));
            }
            else
            {
                sc = 447.6 + (9.2 * Convert.ToDouble(tB_ves.Text)) + (3.1 * Convert.ToDouble(tB_rost.Text)) - (4.3 * Convert.ToDouble(textBox1.Text));
            }
            
            label4.Text = $"Ваш предполагаемый обмен веществ: {sc: 0.00} ккал/день";
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Click(object sender, EventArgs e)
        {
            panel2.BackColor = Color.PowderBlue;
            panel3.BackColor = Color.AliceBlue;
            a = 0;
        }

        private void panel3_Click(object sender, EventArgs e)
        {
            panel3.BackColor = Color.PowderBlue;
            panel2.BackColor = Color.AliceBlue;
            a = 1;
        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }
    }
}
