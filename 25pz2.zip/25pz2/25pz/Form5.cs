﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
            label2.Text = string.Empty;
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.f1_car;
            label2.Text = "345 km/H";
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.slug;
            label2.Text = "0.01 km/H";
        }

        private void panel4_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.horse;
            label2.Text = "15 km/H";
        }

        private void panel5_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.sloth;
            label2.Text = "0.12 km/H";
        }

        private void panel6_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.capybara;
            label2.Text = "35 km/H";
        }

        private void panel7_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.jaguar;
            label2.Text = "80 km/H";
        }

        private void panel8_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.worm;
            label2.Text = "0.03 km/H";
        }

        private void panel13_Click(object sender, EventArgs e)
        {
            
             pB_pic.Image = Properties.Resources.bus;
             label2.Text = "10 m";
            
        }

        private void panel12_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.pair_of_havaianas;
            label2.Text = "0.245 m";
        }

        private void panel11_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.airbus_a380;
            label2.Text = "73 m";
        }

        private void panel10_Click(object sender, EventArgs e)
        {     
            pB_pic.Image = Properties.Resources.football_field;
            label2.Text = "105 m";
        }

        private void panel9_Click(object sender, EventArgs e)
        {
            pB_pic.Image = Properties.Resources.ronaldinho;
            label2.Text = "1.81 m";
        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }
    }
}
