﻿namespace _25pz
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_info = new System.Windows.Forms.Button();
            this.lb_time = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.trB_ves = new System.Windows.Forms.TrackBar();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pB_itog = new System.Windows.Forms.PictureBox();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_schet = new System.Windows.Forms.Button();
            this.tB_ves = new System.Windows.Forms.TextBox();
            this.tB_rost = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_ves = new System.Windows.Forms.Label();
            this.lB_Rost = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pB_female = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lB_man = new System.Windows.Forms.Label();
            this.pB_male = new System.Windows.Forms.PictureBox();
            this.lb_inf = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trB_ves)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_itog)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_female)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_male)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.White;
            this.btn_info.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_info.Location = new System.Drawing.Point(12, 7);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(113, 31);
            this.btn_info.TabIndex = 9;
            this.btn_info.Text = "Назад";
            this.btn_info.UseVisualStyleBackColor = false;
            this.btn_info.Click += new System.EventHandler(this.btn_info_Click);
            // 
            // lb_time
            // 
            this.lb_time.AutoSize = true;
            this.lb_time.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F);
            this.lb_time.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_time.Location = new System.Drawing.Point(168, 422);
            this.lb_time.Name = "lb_time";
            this.lb_time.Size = new System.Drawing.Size(46, 21);
            this.lb_time.TabIndex = 6;
            this.lb_time.Text = "lable";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_name.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_name.Location = new System.Drawing.Point(170, 7);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(320, 31);
            this.lb_name.TabIndex = 8;
            this.lb_name.Text = "MARATHON SKILLS 2016";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Azure;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.trB_ves);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btn_cancel);
            this.panel1.Controls.Add(this.btn_schet);
            this.panel1.Controls.Add(this.tB_ves);
            this.panel1.Controls.Add(this.tB_rost);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lb_ves);
            this.panel1.Controls.Add(this.lB_Rost);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lb_inf);
            this.panel1.Location = new System.Drawing.Point(-3, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(807, 375);
            this.panel1.TabIndex = 7;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Red;
            this.pictureBox4.Location = new System.Drawing.Point(613, 313);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(178, 20);
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Gold;
            this.pictureBox3.Location = new System.Drawing.Point(592, 313);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 20);
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBox2.Location = new System.Drawing.Point(556, 313);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(37, 20);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gold;
            this.pictureBox1.Location = new System.Drawing.Point(445, 313);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 20);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // trB_ves
            // 
            this.trB_ves.Location = new System.Drawing.Point(445, 276);
            this.trB_ves.Maximum = 60;
            this.trB_ves.Name = "trB_ves";
            this.trB_ves.Size = new System.Drawing.Size(346, 45);
            this.trB_ves.TabIndex = 12;
            this.trB_ves.Value = 29;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.pB_itog);
            this.panel4.Location = new System.Drawing.Point(522, 48);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(186, 213);
            this.panel4.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.label4.Location = new System.Drawing.Point(57, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Женский";
            // 
            // pB_itog
            // 
            this.pB_itog.Location = new System.Drawing.Point(33, 18);
            this.pB_itog.Name = "pB_itog";
            this.pB_itog.Size = new System.Drawing.Size(123, 166);
            this.pB_itog.TabIndex = 0;
            this.pB_itog.TabStop = false;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(180, 276);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(111, 23);
            this.btn_cancel.TabIndex = 11;
            this.btn_cancel.Text = "Отмена";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // btn_schet
            // 
            this.btn_schet.Location = new System.Drawing.Point(52, 276);
            this.btn_schet.Name = "btn_schet";
            this.btn_schet.Size = new System.Drawing.Size(122, 23);
            this.btn_schet.TabIndex = 10;
            this.btn_schet.Text = "Рассчитать";
            this.btn_schet.UseVisualStyleBackColor = true;
            this.btn_schet.Click += new System.EventHandler(this.btn_schet_Click);
            // 
            // tB_ves
            // 
            this.tB_ves.Location = new System.Drawing.Point(146, 241);
            this.tB_ves.Name = "tB_ves";
            this.tB_ves.Size = new System.Drawing.Size(65, 20);
            this.tB_ves.TabIndex = 9;
            // 
            // tB_rost
            // 
            this.tB_rost.Location = new System.Drawing.Point(146, 198);
            this.tB_rost.Name = "tB_rost";
            this.tB_rost.Size = new System.Drawing.Size(65, 20);
            this.tB_rost.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.label3.Location = new System.Drawing.Point(217, 242);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "кг";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.label2.Location = new System.Drawing.Point(217, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "см";
            // 
            // lb_ves
            // 
            this.lb_ves.AutoSize = true;
            this.lb_ves.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lb_ves.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.lb_ves.Location = new System.Drawing.Point(96, 242);
            this.lb_ves.Name = "lb_ves";
            this.lb_ves.Size = new System.Drawing.Size(36, 17);
            this.lb_ves.TabIndex = 5;
            this.lb_ves.Text = "Вес:";
            // 
            // lB_Rost
            // 
            this.lB_Rost.AutoSize = true;
            this.lB_Rost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lB_Rost.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.lB_Rost.Location = new System.Drawing.Point(96, 198);
            this.lB_Rost.Name = "lB_Rost";
            this.lB_Rost.Size = new System.Drawing.Size(43, 17);
            this.lB_Rost.TabIndex = 2;
            this.lB_Rost.Text = "Рост:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.pB_female);
            this.panel3.Location = new System.Drawing.Point(179, 89);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(112, 100);
            this.panel3.TabIndex = 4;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            this.panel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.label1.Location = new System.Drawing.Point(21, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Женский";
            // 
            // pB_female
            // 
            this.pB_female.Enabled = false;
            this.pB_female.Image = global::_25pz.Properties.Resources.female;
            this.pB_female.Location = new System.Drawing.Point(30, 3);
            this.pB_female.Name = "pB_female";
            this.pB_female.Size = new System.Drawing.Size(50, 66);
            this.pB_female.TabIndex = 0;
            this.pB_female.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.PowderBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lB_man);
            this.panel2.Controls.Add(this.pB_male);
            this.panel2.Location = new System.Drawing.Point(52, 89);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(112, 100);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            this.panel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseClick);
            // 
            // lB_man
            // 
            this.lB_man.AutoSize = true;
            this.lB_man.Enabled = false;
            this.lB_man.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lB_man.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.lB_man.Location = new System.Drawing.Point(21, 73);
            this.lB_man.Name = "lB_man";
            this.lB_man.Size = new System.Drawing.Size(65, 17);
            this.lB_man.TabIndex = 1;
            this.lB_man.Text = "Мужской";
            // 
            // pB_male
            // 
            this.pB_male.Enabled = false;
            this.pB_male.Image = global::_25pz.Properties.Resources.male;
            this.pB_male.Location = new System.Drawing.Point(30, 3);
            this.pB_male.Name = "pB_male";
            this.pB_male.Size = new System.Drawing.Size(50, 66);
            this.pB_male.TabIndex = 0;
            this.pB_male.TabStop = false;
            // 
            // lb_inf
            // 
            this.lb_inf.AutoSize = true;
            this.lb_inf.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_inf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.lb_inf.Location = new System.Drawing.Point(276, 0);
            this.lb_inf.Name = "lb_inf";
            this.lb_inf.Size = new System.Drawing.Size(229, 31);
            this.lb_inf.TabIndex = 2;
            this.lb_inf.Text = "BMI калькулятор";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_info);
            this.Controls.Add(this.lb_time);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.panel1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form4_FormClosed);
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trB_ves)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_itog)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_female)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_male)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_info;
        private System.Windows.Forms.Label lb_time;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_inf;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pB_male;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pB_female;
        private System.Windows.Forms.Label lB_man;
        private System.Windows.Forms.TrackBar trB_ves;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pB_itog;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_schet;
        private System.Windows.Forms.TextBox tB_ves;
        private System.Windows.Forms.TextBox tB_rost;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_ves;
        private System.Windows.Forms.Label lB_Rost;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}