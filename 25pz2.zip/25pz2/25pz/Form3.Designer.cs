﻿namespace _25pz
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.lb_name = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_rast = new System.Windows.Forms.Button();
            this.BTN_half = new System.Windows.Forms.Button();
            this.BTN_start = new System.Windows.Forms.Button();
            this.BTN_checkpoint8 = new System.Windows.Forms.Button();
            this.BTN_checkpoint7 = new System.Windows.Forms.Button();
            this.BTN_checkpoint6 = new System.Windows.Forms.Button();
            this.BTN_checkpoint5 = new System.Windows.Forms.Button();
            this.BTN_checkpoint4 = new System.Windows.Forms.Button();
            this.BTN_checkpoint3 = new System.Windows.Forms.Button();
            this.BTN_checkpoint2 = new System.Windows.Forms.Button();
            this.pnl_checkpoint1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LB_nld = new System.Windows.Forms.Label();
            this.lb_landmark = new System.Windows.Forms.Label();
            this.lb_name2 = new System.Windows.Forms.Label();
            this.BTN_checkpoint1 = new System.Windows.Forms.Button();
            this.pB_map = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnl_checkpoint1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_map)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_name.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_name.Location = new System.Drawing.Point(157, 9);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(598, 31);
            this.lb_name.TabIndex = 7;
            this.lb_name.Text = "Интерактивная карта MARATHON SKILLS 2016";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Azure;
            this.panel1.Controls.Add(this.BTN_rast);
            this.panel1.Controls.Add(this.BTN_half);
            this.panel1.Controls.Add(this.BTN_start);
            this.panel1.Controls.Add(this.BTN_checkpoint8);
            this.panel1.Controls.Add(this.BTN_checkpoint7);
            this.panel1.Controls.Add(this.BTN_checkpoint6);
            this.panel1.Controls.Add(this.BTN_checkpoint5);
            this.panel1.Controls.Add(this.BTN_checkpoint4);
            this.panel1.Controls.Add(this.BTN_checkpoint3);
            this.panel1.Controls.Add(this.BTN_checkpoint2);
            this.panel1.Controls.Add(this.pnl_checkpoint1);
            this.panel1.Controls.Add(this.BTN_checkpoint1);
            this.panel1.Controls.Add(this.pB_map);
            this.panel1.Location = new System.Drawing.Point(-3, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(807, 411);
            this.panel1.TabIndex = 6;
            // 
            // BTN_rast
            // 
            this.BTN_rast.BackColor = System.Drawing.Color.Transparent;
            this.BTN_rast.BackgroundImage = global::_25pz.Properties.Resources.start2;
            this.BTN_rast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_rast.FlatAppearance.BorderSize = 0;
            this.BTN_rast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_rast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_rast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_rast.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_rast.Location = new System.Drawing.Point(3, 156);
            this.BTN_rast.Name = "BTN_rast";
            this.BTN_rast.Size = new System.Drawing.Size(53, 62);
            this.BTN_rast.TabIndex = 22;
            this.BTN_rast.UseVisualStyleBackColor = false;
            // 
            // BTN_half
            // 
            this.BTN_half.BackColor = System.Drawing.Color.Transparent;
            this.BTN_half.BackgroundImage = global::_25pz.Properties.Resources.start2;
            this.BTN_half.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_half.FlatAppearance.BorderSize = 0;
            this.BTN_half.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_half.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_half.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_half.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_half.Location = new System.Drawing.Point(200, 309);
            this.BTN_half.Name = "BTN_half";
            this.BTN_half.Size = new System.Drawing.Size(53, 62);
            this.BTN_half.TabIndex = 21;
            this.BTN_half.UseVisualStyleBackColor = false;
            // 
            // BTN_start
            // 
            this.BTN_start.BackColor = System.Drawing.Color.Transparent;
            this.BTN_start.BackgroundImage = global::_25pz.Properties.Resources.start2;
            this.BTN_start.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_start.FlatAppearance.BorderSize = 0;
            this.BTN_start.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_start.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_start.Location = new System.Drawing.Point(107, 18);
            this.BTN_start.Name = "BTN_start";
            this.BTN_start.Size = new System.Drawing.Size(53, 62);
            this.BTN_start.TabIndex = 20;
            this.BTN_start.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint8
            // 
            this.BTN_checkpoint8.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint8.BackgroundImage = global::_25pz.Properties.Resources._8;
            this.BTN_checkpoint8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint8.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint8.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint8.Location = new System.Drawing.Point(20, 100);
            this.BTN_checkpoint8.Name = "BTN_checkpoint8";
            this.BTN_checkpoint8.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint8.TabIndex = 19;
            this.BTN_checkpoint8.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint7
            // 
            this.BTN_checkpoint7.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint7.BackgroundImage = global::_25pz.Properties.Resources._7;
            this.BTN_checkpoint7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint7.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint7.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint7.Location = new System.Drawing.Point(31, 214);
            this.BTN_checkpoint7.Name = "BTN_checkpoint7";
            this.BTN_checkpoint7.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint7.TabIndex = 18;
            this.BTN_checkpoint7.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint6
            // 
            this.BTN_checkpoint6.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint6.BackgroundImage = global::_25pz.Properties.Resources._6;
            this.BTN_checkpoint6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint6.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint6.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint6.Location = new System.Drawing.Point(59, 268);
            this.BTN_checkpoint6.Name = "BTN_checkpoint6";
            this.BTN_checkpoint6.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint6.TabIndex = 17;
            this.BTN_checkpoint6.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint5
            // 
            this.BTN_checkpoint5.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint5.BackgroundImage = global::_25pz.Properties.Resources._5;
            this.BTN_checkpoint5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint5.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint5.Location = new System.Drawing.Point(145, 309);
            this.BTN_checkpoint5.Name = "BTN_checkpoint5";
            this.BTN_checkpoint5.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint5.TabIndex = 16;
            this.BTN_checkpoint5.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint4
            // 
            this.BTN_checkpoint4.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint4.BackgroundImage = global::_25pz.Properties.Resources._4;
            this.BTN_checkpoint4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint4.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint4.Location = new System.Drawing.Point(268, 256);
            this.BTN_checkpoint4.Name = "BTN_checkpoint4";
            this.BTN_checkpoint4.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint4.TabIndex = 15;
            this.BTN_checkpoint4.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint3
            // 
            this.BTN_checkpoint3.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint3.BackgroundImage = global::_25pz.Properties.Resources._3;
            this.BTN_checkpoint3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint3.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint3.Location = new System.Drawing.Point(189, 175);
            this.BTN_checkpoint3.Name = "BTN_checkpoint3";
            this.BTN_checkpoint3.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint3.TabIndex = 14;
            this.BTN_checkpoint3.UseVisualStyleBackColor = false;
            // 
            // BTN_checkpoint2
            // 
            this.BTN_checkpoint2.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint2.BackgroundImage = global::_25pz.Properties.Resources._2;
            this.BTN_checkpoint2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint2.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint2.Location = new System.Drawing.Point(200, 107);
            this.BTN_checkpoint2.Name = "BTN_checkpoint2";
            this.BTN_checkpoint2.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint2.TabIndex = 13;
            this.BTN_checkpoint2.UseVisualStyleBackColor = false;
            this.BTN_checkpoint2.Click += new System.EventHandler(this.BTN_checkpoint2_Click);
            // 
            // pnl_checkpoint1
            // 
            this.pnl_checkpoint1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnl_checkpoint1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_checkpoint1.Controls.Add(this.btnClose);
            this.pnl_checkpoint1.Controls.Add(this.label3);
            this.pnl_checkpoint1.Controls.Add(this.label2);
            this.pnl_checkpoint1.Controls.Add(this.pictureBox2);
            this.pnl_checkpoint1.Controls.Add(this.pictureBox1);
            this.pnl_checkpoint1.Controls.Add(this.label1);
            this.pnl_checkpoint1.Controls.Add(this.LB_nld);
            this.pnl_checkpoint1.Controls.Add(this.lb_landmark);
            this.pnl_checkpoint1.Controls.Add(this.lb_name2);
            this.pnl_checkpoint1.Location = new System.Drawing.Point(476, 26);
            this.pnl_checkpoint1.Name = "pnl_checkpoint1";
            this.pnl_checkpoint1.Size = new System.Drawing.Size(305, 369);
            this.pnl_checkpoint1.TabIndex = 12;
            this.pnl_checkpoint1.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(250, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 23);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Energy bars";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Drinks";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::_25pz.Properties.Resources.enrgy_bars;
            this.pictureBox2.InitialImage = global::_25pz.Properties.Resources.drinks;
            this.pictureBox2.Location = new System.Drawing.Point(18, 229);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(58, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_25pz.Properties.Resources.drinks;
            this.pictureBox1.InitialImage = global::_25pz.Properties.Resources.drinks;
            this.pictureBox1.Location = new System.Drawing.Point(18, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.Location = new System.Drawing.Point(45, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Services provided:";
            // 
            // LB_nld
            // 
            this.LB_nld.AutoSize = true;
            this.LB_nld.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.LB_nld.ForeColor = System.Drawing.Color.Silver;
            this.LB_nld.Location = new System.Drawing.Point(66, 67);
            this.LB_nld.Name = "LB_nld";
            this.LB_nld.Size = new System.Drawing.Size(177, 29);
            this.LB_nld.TabIndex = 2;
            this.LB_nld.Text = "Avenida Rudge";
            // 
            // lb_landmark
            // 
            this.lb_landmark.AutoSize = true;
            this.lb_landmark.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lb_landmark.ForeColor = System.Drawing.Color.DarkGray;
            this.lb_landmark.Location = new System.Drawing.Point(13, 38);
            this.lb_landmark.Name = "lb_landmark";
            this.lb_landmark.Size = new System.Drawing.Size(191, 29);
            this.lb_landmark.TabIndex = 1;
            this.lb_landmark.Text = "Landmark name:";
            // 
            // lb_name2
            // 
            this.lb_name2.AutoSize = true;
            this.lb_name2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lb_name2.ForeColor = System.Drawing.Color.Gray;
            this.lb_name2.Location = new System.Drawing.Point(70, 9);
            this.lb_name2.Name = "lb_name2";
            this.lb_name2.Size = new System.Drawing.Size(173, 31);
            this.lb_name2.TabIndex = 0;
            this.lb_name2.Text = "Checkpoint 1";
            // 
            // BTN_checkpoint1
            // 
            this.BTN_checkpoint1.BackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint1.BackgroundImage = global::_25pz.Properties.Resources._1;
            this.BTN_checkpoint1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTN_checkpoint1.FlatAppearance.BorderSize = 0;
            this.BTN_checkpoint1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BTN_checkpoint1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_checkpoint1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F);
            this.BTN_checkpoint1.Location = new System.Drawing.Point(166, 2);
            this.BTN_checkpoint1.Name = "BTN_checkpoint1";
            this.BTN_checkpoint1.Size = new System.Drawing.Size(53, 62);
            this.BTN_checkpoint1.TabIndex = 4;
            this.BTN_checkpoint1.UseVisualStyleBackColor = false;
            this.BTN_checkpoint1.Click += new System.EventHandler(this.BTN_checkpoint1_Click);
            // 
            // pB_map
            // 
            this.pB_map.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_map.Image = ((System.Drawing.Image)(resources.GetObject("pB_map.Image")));
            this.pB_map.Location = new System.Drawing.Point(15, 13);
            this.pB_map.Name = "pB_map";
            this.pB_map.Size = new System.Drawing.Size(321, 382);
            this.pB_map.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_map.TabIndex = 3;
            this.pB_map.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.pnl_checkpoint1.ResumeLayout(false);
            this.pnl_checkpoint1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_map)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pB_map;
        private System.Windows.Forms.Button BTN_checkpoint1;
        private System.Windows.Forms.Panel pnl_checkpoint1;
        private System.Windows.Forms.Label lb_name2;
        private System.Windows.Forms.Label lb_landmark;
        private System.Windows.Forms.Label LB_nld;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button BTN_rast;
        private System.Windows.Forms.Button BTN_half;
        private System.Windows.Forms.Button BTN_start;
        private System.Windows.Forms.Button BTN_checkpoint8;
        private System.Windows.Forms.Button BTN_checkpoint7;
        private System.Windows.Forms.Button BTN_checkpoint6;
        private System.Windows.Forms.Button BTN_checkpoint5;
        private System.Windows.Forms.Button BTN_checkpoint4;
        private System.Windows.Forms.Button BTN_checkpoint3;
        private System.Windows.Forms.Button BTN_checkpoint2;
        private System.Windows.Forms.Button button1;
    }
}