﻿namespace _25pz
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_BMR = new System.Windows.Forms.Button();
            this.btn_BMI = new System.Windows.Forms.Button();
            this.btn_timeinfo = new System.Windows.Forms.Button();
            this.btn_info = new System.Windows.Forms.Button();
            this.lb_inf = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_time = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Azure;
            this.panel1.Controls.Add(this.btn_BMR);
            this.panel1.Controls.Add(this.btn_BMI);
            this.panel1.Controls.Add(this.btn_timeinfo);
            this.panel1.Controls.Add(this.btn_info);
            this.panel1.Controls.Add(this.lb_inf);
            this.panel1.Location = new System.Drawing.Point(-3, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(807, 375);
            this.panel1.TabIndex = 0;
            // 
            // btn_BMR
            // 
            this.btn_BMR.BackColor = System.Drawing.Color.White;
            this.btn_BMR.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_BMR.Location = new System.Drawing.Point(378, 138);
            this.btn_BMR.Name = "btn_BMR";
            this.btn_BMR.Size = new System.Drawing.Size(299, 54);
            this.btn_BMR.TabIndex = 6;
            this.btn_BMR.Text = "BMR калькулятор";
            this.btn_BMR.UseVisualStyleBackColor = false;
            this.btn_BMR.Click += new System.EventHandler(this.btn_BMR_Click);
            // 
            // btn_BMI
            // 
            this.btn_BMI.BackColor = System.Drawing.Color.White;
            this.btn_BMI.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_BMI.Location = new System.Drawing.Point(73, 138);
            this.btn_BMI.Name = "btn_BMI";
            this.btn_BMI.Size = new System.Drawing.Size(299, 54);
            this.btn_BMI.TabIndex = 5;
            this.btn_BMI.Text = "BMI калькулятор";
            this.btn_BMI.UseVisualStyleBackColor = false;
            this.btn_BMI.Click += new System.EventHandler(this.btn_BMI_Click);
            // 
            // btn_timeinfo
            // 
            this.btn_timeinfo.BackColor = System.Drawing.Color.White;
            this.btn_timeinfo.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_timeinfo.Location = new System.Drawing.Point(378, 69);
            this.btn_timeinfo.Name = "btn_timeinfo";
            this.btn_timeinfo.Size = new System.Drawing.Size(299, 54);
            this.btn_timeinfo.TabIndex = 4;
            this.btn_timeinfo.Text = "Насколько долгий марафон";
            this.btn_timeinfo.UseVisualStyleBackColor = false;
            this.btn_timeinfo.Click += new System.EventHandler(this.btn_timeinfo_Click);
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.White;
            this.btn_info.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_info.Location = new System.Drawing.Point(73, 69);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(299, 54);
            this.btn_info.TabIndex = 3;
            this.btn_info.Text = "Marathon Skills 2016";
            this.btn_info.UseVisualStyleBackColor = false;
            this.btn_info.Click += new System.EventHandler(this.btn_info_Click);
            // 
            // lb_inf
            // 
            this.lb_inf.AutoSize = true;
            this.lb_inf.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_inf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.lb_inf.Location = new System.Drawing.Point(126, 11);
            this.lb_inf.Name = "lb_inf";
            this.lb_inf.Size = new System.Drawing.Size(551, 31);
            this.lb_inf.TabIndex = 2;
            this.lb_inf.Text = "ИНФОРМАЦИЯ О MARATHON SKILLS 2016";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_name.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_name.Location = new System.Drawing.Point(64, 9);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(320, 31);
            this.lb_name.TabIndex = 1;
            this.lb_name.Text = "MARATHON SKILLS 2016";
            // 
            // lb_time
            // 
            this.lb_time.AutoSize = true;
            this.lb_time.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F);
            this.lb_time.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_time.Location = new System.Drawing.Point(168, 422);
            this.lb_time.Name = "lb_time";
            this.lb_time.Size = new System.Drawing.Size(46, 21);
            this.lb_time.TabIndex = 0;
            this.lb_time.Text = "lable";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(92)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_time);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_time;
        private System.Windows.Forms.Label lb_inf;
        private System.Windows.Forms.Button btn_BMR;
        private System.Windows.Forms.Button btn_BMI;
        private System.Windows.Forms.Button btn_timeinfo;
        private System.Windows.Forms.Button btn_info;
        private System.Windows.Forms.Timer timer1;
    }
}

