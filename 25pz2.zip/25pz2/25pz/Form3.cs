﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            pB_map.SizeMode = PictureBoxSizeMode.StretchImage;
            BTN_checkpoint1.Parent = pB_map;
            BTN_checkpoint2.Parent = pB_map;
            BTN_checkpoint3.Parent = pB_map;
            BTN_checkpoint4.Parent = pB_map;
            BTN_checkpoint5.Parent = pB_map;
            BTN_checkpoint6.Parent = pB_map;
            BTN_checkpoint7.Parent = pB_map;
            BTN_checkpoint8.Parent = pB_map;
            BTN_start.Parent = pB_map;
            BTN_half.Parent = pB_map;
            BTN_rast.Parent = pB_map;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Form2 Main = this.Owner as Form2;
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BTN_checkpoint1_Click(object sender, EventArgs e)
        {
            pnl_checkpoint1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnl_checkpoint1.Visible = false;
        }

        private void BTN_checkpoint2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }
    }
}
