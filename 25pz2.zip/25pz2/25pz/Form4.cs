﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25pz
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            pB_male.SizeMode = PictureBoxSizeMode.StretchImage;
            pB_female.SizeMode = PictureBoxSizeMode.StretchImage;
            trB_ves.Enabled = false;
        }

        private void btn_info_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 AddRec = new Form1();
            AddRec.StartPosition = FormStartPosition.Manual;
            AddRec.Location = Location;
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            panel2.BackColor= Color.PowderBlue;
            panel3.BackColor= Color.AliceBlue;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            panel3.BackColor = Color.PowderBlue;
            panel2.BackColor = Color.AliceBlue;
        }

        private void btn_schet_Click(object sender, EventArgs e)
        {
            Bitmap bmp = null;
            double a = Convert.ToDouble(tB_rost.Text);
            double b = Convert.ToDouble(tB_ves.Text);
            double c = b/Math.Pow(2, a);
            if (trB_ves.Minimum < c && trB_ves.Maximum > c)
            {
                trB_ves.Value = (int)c;
            }
            else
            {
                if(trB_ves.Minimum > c)
                {
                    trB_ves.Value = trB_ves.Minimum;
                }
                else
                {
                    trB_ves.Value = trB_ves.Maximum;
                }
            }
            if(trB_ves.Value<19)
            {
                pB_itog.Image = Properties.Resources.bmi_underweight_icon;
                pB_itog.SizeMode = PictureBoxSizeMode.StretchImage;
                label4.Text = "Недовес";
            }
            else
            {
                if(trB_ves.Value>19&&trB_ves.Value<25)
                {
                    pB_itog.Image = Properties.Resources.bmi_healthy_icon;
                    pB_itog.SizeMode = PictureBoxSizeMode.StretchImage;
                    label4.Text = "Здоровый";
                }
                else
                {
                    if(trB_ves.Value>25&&trB_ves.Value<30)
                    {
                        pB_itog.Image = Properties.Resources.bmi_obese_icon;
                        pB_itog.SizeMode = PictureBoxSizeMode.StretchImage;
                        label4.Text = "Избыточный вес";
                    }
                    else
                    {
                        pB_itog.Image = Properties.Resources.bmi_overweight_icon;
                        pB_itog.SizeMode = PictureBoxSizeMode.StretchImage;
                        label4.Text = "Ожирение";
                    }
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
